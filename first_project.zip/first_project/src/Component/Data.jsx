const Data = [{
    player : 'Rohit',
    number : '45'
},
{
    player : 'Kohli',
    number : '18'
},
{
    player : 'Gill',
    number : '77'
},
{
    player : 'Jadeja',
    number : '8'
},
{
    player : 'Rahul',
    number : '1'
},
{
    player : 'Rohit',
    number : '45'
}]

export default Data;



